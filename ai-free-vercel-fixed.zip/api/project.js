module.exports = function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed. Use POST.' });
  }

  const body = req.body || {};
  const topic = typeof body.topic === 'string' ? body.topic.trim().slice(0, 500) : '';
  const language = ['English', 'Sinhala', 'English + Sinhala'].includes(body.language) ? body.language : 'English';
  const type = typeof body.type === 'string' ? body.type.slice(0, 80) : 'Faceless video';
  const duration = typeof body.duration === 'string' ? body.duration.slice(0, 30) : '30 seconds';
  const style = typeof body.style === 'string' ? body.style.slice(0, 50) : 'Cinematic';

  if (!topic) return res.status(400).json({ error: 'Please enter a video topic.' });

  let script;
  if (language === 'Sinhala') {
    script = `ආයුබෝවන්! අද අපි කතා කරන්නේ ${topic} ගැනයි.\n\nමෙම මාතෘකාවේ වැදගත් කරුණු කිහිපයක් අපි සරලව සහ රසවත් ලෙස බලමු.\n\nමෙම වීඩියෝව ඔබට ප්‍රයෝජනවත් නම් Like කරන්න, Share කරන්න සහ තවත් වීඩියෝ සඳහා Follow කරන්න. ස්තුතියි!`;
  } else if (language === 'English + Sinhala') {
    script = `Hello! අද අපි කතා කරන්නේ ${topic} ගැනයි.\n\nLet's explore the key points in a simple and engaging way. වැදගත් කරුණු කිහිපයක් දැන් බලමු.\n\nLike, share and follow for more. තවත් වීඩියෝ සඳහා අප සමඟ රැඳී සිටින්න. Thank you!`;
  } else {
    script = `Welcome! Today we're exploring ${topic}.\n\nHere are the key points you need to know, explained in a simple and engaging way.\n\nIf you found this video useful, like, share and follow for more. Thanks for watching!`;
  }

  return res.status(200).json({
    id: Date.now().toString(36), topic, language, type, duration, style,
    script, status: 'draft',
    note: 'Starter script template. Connect an AI language model and video provider for full AI generation.'
  });
};
